#pragma once
#include <string>
#include <vector>

struct Person
{
	std::string name;
	int age;
	std::string address;
	std::vector<std::string> hobbies;

};