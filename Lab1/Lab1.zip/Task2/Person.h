#pragma once
#include <string>
struct Person
{
	std::string name;
	int age;
	std::string address;
};